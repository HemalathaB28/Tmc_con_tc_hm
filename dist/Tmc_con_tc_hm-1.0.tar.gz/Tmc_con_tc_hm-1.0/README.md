# TIME CONVERTOR
#### TIME CONVERSION OF SECONDS TO MINUTES,HOURS AND DAYS


## Installation 
Run the following code to install this package:
   '''cmd pip install Tmc_con_tc_hm'''

##contributer: HEMALATHA B
